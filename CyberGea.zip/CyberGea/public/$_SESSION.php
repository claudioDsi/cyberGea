<?php

$GLOBALS['PROTOCOL']= 'http';


function GetInfo()
	{

	 //$ch = curl_init(dirname($GLOBALS['PROTOCOL'].'://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']).'/paziente/medico/'.$medico);
	 
	if (isset($_SESSION["infodashboard"]))
	{
		unset($_SESSION["infodashboard"]);
	}
	 
	 $info["type"]="updateui";
	 $data_string = json_encode($info);
	 
	 
	 $ch = curl_init();
	 curl_setopt($ch, CURLOPT_URL, 'http://192.168.1.7:8080/pres');
	 curl_setopt($ch, CURLOPT_POST, true);
	 //curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	 curl_setopt($ch, CURLOPT_USERAGENT, 'YourScript/0.1 (contact@email)');
	 curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
	 
	 //$arr = array('session_id' => $_SESSION['id'], 'session_token' => $_SESSION['token']);
	 
	 curl_setopt($ch, CURLOPT_HTTPHEADER, array
	 (
	 'X-HTTP-Method-Override: POST',
	 'Content-Type: application/json',
	 //'Authorization: Bearer ' . $_SESSION["token"],
	 //'SessionId:'.http_build_query($arr),
	 ));
	 
	 $result = curl_exec($ch);
	 
	 
	 $info = curl_getinfo($ch);
	 $err = curl_error($ch);
	 
	 
	 curl_close($ch);
	 
	 $res = json_decode($result,true);
	 

	 if (isset($_SESSION["infodashboard"]))
	 {
		unset($_SESSION["infodashboard"]);
	 }
	 
	 $_SESSION["infodashboard"]=$res;
// 	 var_dump($_SESSION["infodashboard"]);
// 	 die();

	}

	GetInfo();

?>
