<?php

$GLOBALS['PROTOCOL']= 'http';


function GetInfo()
	{

	 //$ch = curl_init(dirname($GLOBALS['PROTOCOL'].'://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']).'/paziente/medico/'.$medico);
	 
	 $ch = curl_init('http://10.170.11.136:8080/pres');
	 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	 curl_setopt($ch, CURLOPT_USERAGENT, 'YourScript/0.1 (contact@email)');
	 
	 //$arr = array('session_id' => $_SESSION['id'], 'session_token' => $_SESSION['token']);
	 
	 curl_setopt($ch, CURLOPT_HTTPHEADER, array
		(
		 'Content-Type: application/json',
		 //'Authorization: Bearer ' . $token,
		 //'SessionId:'.http_build_query($arr),
		));

	 $result = curl_exec($ch);
	 $info = curl_getinfo($ch);
	 $err = curl_error($ch);
	 curl_close($ch);

	 $_SESSION["info"]=json_decode($result, true);	
	 

	}

	//GetInfo();

?>
