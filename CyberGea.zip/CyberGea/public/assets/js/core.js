
$(document).ready(function()
	{
		
		$(".img_click").click(function(event){
			
			event.preventDefault();
		   
			var elem = $(this).closest("div").prev("h3").html();
			
			var checkbox = '<p><input type="checkbox" id="primavera" value="Primavera"><label for="primavera">Primavera</label></p>';
			$(this).closest("div").append(checkbox);
			
			//alert($(this).closest("div").prev("h3").html());
			
//			$.ajax({
//				    url: "http://10.170.51.63:8080/pres",
//				    type: "POST",
//				    data: {season: elem},
//				    dataType : 'json',
//				    success: function(data){
//				    	alert("success");
//				        alert(data);
//				        var checkbox = '<label><input type="checkbox" />Checkbox</label>';
//				        $(this).append("<h1>ciao</h1>");
//	
//				    },
//				    error: function (request, status, error) {
//				    	alert("error");
//				    	alert(request.responseText);
//				    	//var checkbox = '<label><input type="checkbox" />Checkbox</label>';
//				    	$(this).append("<h1>ciao</h1>");
//				    }
//			});     
	     });
	
//		$.ajax({
//		    url: "http://10.171.11.229:8080/pres",
//		    type: "GET",
//		    dataType : 'text',
//		    success: function(data){
//		        alert(data);
////		    	$.each(data, function(index, element) {
////		            $('body').append($('<div>', {
////		                text: element.name
////		            }));
////		        });
//		    },
//		    error: function (request, status, error) {
//		        alert(request.responseText);
//		    }
//		});
		
	});
