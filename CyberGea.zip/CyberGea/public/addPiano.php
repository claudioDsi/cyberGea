<?php

session_start();
require_once '$_SESSION.php';

// function GetProva()
// 	{
// 	 $medico=base64_encode($id);

// 	 //$ch = curl_init(dirname($GLOBALS['PROTOCOL'].'://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']).'/paziente/medico/'.$medico);
	 
// 	 $ch = curl_init('http://10.170.11.136:8080/pres');
// 	 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
// 	 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
// 	 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// 	 curl_setopt($ch, CURLOPT_USERAGENT, 'YourScript/0.1 (contact@email)');
	 
// 	 //$arr = array('session_id' => $_SESSION['id'], 'session_token' => $_SESSION['token']);
	 
// 	 curl_setopt($ch, CURLOPT_HTTPHEADER, array
// 		(
// 		 'Content-Type: application/json',
// 		 //'Authorization: Bearer ' . $token,
// 		 //'SessionId:'.http_build_query($arr),
// 		));

// 	 $result = curl_exec($ch);
// 	 $info = curl_getinfo($ch);
// 	 $err = curl_error($ch);
// 	 curl_close($ch);

// 	 $_SESSION["result"]=json_decode($result, true);	
	 

// 	}

// $post = [
// 'seasons' => $_POST,
// 'type' => "productchosen",
// ];



$_POST["type"]="productchosen";
$data_string = json_encode($_POST);


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://192.168.1.7:8080/pres');
curl_setopt($ch, CURLOPT_POST, true);
//curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_USERAGENT, 'YourScript/0.1 (contact@email)');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);

//$arr = array('session_id' => $_SESSION['id'], 'session_token' => $_SESSION['token']);

curl_setopt($ch, CURLOPT_HTTPHEADER, array
(
'X-HTTP-Method-Override: POST',
'Content-Type: application/json',
//'Authorization: Bearer ' . $_SESSION["token"],
//'SessionId:'.http_build_query($arr),
));

$result = curl_exec($ch);

$info = curl_getinfo($ch);
$err = curl_error($ch);


curl_close($ch);

$res = json_decode($result,true);




unset($_POST["type"]);
$_SESSION["prodottiperstagione"]=$res;
// var_dump($_SESSION["prodottiperstagione"]);
// die();



//caso in cui non ci sono errori
if(isset($res))
{
	//devo mostrare pagina con riepilogo appuntamento aggiunto?o basta messaggio inserimento andato a buon fine
	$_SESSION['addpianook']=1;

	//richiamare l'elenco dei piani
	header('Location: resoconto');

	exit;
}

//caso in cui sono presenti errori
else
{
	$_SESSION['addpianonotok']=1;

	header('Location: resoconto');

	exit;
}



?>
