<?php

use App\Controllers\_ApiController;
use App\Controllers\_Controller;
use App\Controllers\_Controller_oAuth2;
use App\Controllers\_oAuth2TokenController;

// Custom Controllers
//use App\Controllers\MyCustomController;

// Routes


$app->group('/home', function()
{
	$this->get('', _Controller::class.':homepage');
});

$app->get('/piano', _Controller::class.':piano');

$app->get('/resoconto', _Controller::class.':resoconto');



     
?>
