<?php

namespace App\DataAccess;

use Psr\Log\LoggerInterface;
use PDO;

 
/**
 * Class _DataAccess.
 */
class _DataAccess
    {
     /**
      * @var \Psr\Log\LoggerInterface
      */
     private $logger;

     /**
      * @var \PDO
      */
     private $pdo;
    
     /**
      * @var \App\DataAccess
      */
     private $maintable;

    
     /**
      * @param \Psr\Log\LoggerInterface $logger
      * @param \PDO                     $pdo
      */
     public function __construct(LoggerInterface $logger, PDO $pdo, $table)
        {
         $this->logger    = $logger;
         $this->pdo       = $pdo;
         $this->maintable = $table;
        }


     public function getAssunzione_farmaco($args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $id = implode(',', array_keys($args));
        
         // decodifica l'ID della prescrizione, che viene passato in base 64
         $args[$id] = base64_decode($args[$id]);

         // Trova le assunzioni_farmaco di oggi, relative ad una certa prescrizione associata ad un paziente,
         // tali che l'assunzione sia stata fatta dopo l'orario della prescrizione ed entro un'ora da esso
         $sql = "SELECT id_assunzione_farmaco FROM assunzione_farmaco, prescrizione WHERE prescrizione.id_paziente=assunzione_farmaco.id_paziente AND prescrizione.id_prescrizione=". $args[$id] ." AND prescrizione.id_prescrizione=assunzione_farmaco.id_prescrizione AND 
date(assunzione_farmaco.timestamp)=curdate() AND time(assunzione_farmaco.timestamp)>prescrizione.ora_assunzione AND time(assunzione_farmaco.timestamp)<addtime(prescrizione.ora_assunzione,'01:00:00')";
  
         $sql2 = "SELECT id_paziente FROM prescrizione WHERE prescrizione.id_prescrizione=". $args[$id];

         // AND prescrizione.ora_assunzione<time(now())

         $stmt = $this->pdo->prepare($sql);
         $stmt2 = $this->pdo->prepare($sql2);

         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));

         $stmt->execute();
         $stmt2->execute();

         //valuto tutti i casi
         $pasticchePrescritte = $this->getNumero_Pasticche($args);

         // caso1: la prescrizione è stata rispettata
         if($stmt->rowCount() == $pasticchePrescritte)
            {  
             //$result = $stmt->fetch(\PDO::FETCH_ASSOC);
             $result = array();

             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {
                 $result[] = $row;
                }
  
             $result['id_prescrizione'] = $args[$id];
             $result['error'] = false;
             $result['message'] = 'la prescrizione è stata rispettata';
            }
   
         //caso2: il numero di pasticche prese è minore o maggiore di quelle prescritte, devo restituire il numero di pasticche che ha preso
         elseif($stmt->rowCount() != $pasticchePrescritte)
            {
             $result['id_prescrizione'] = $args[$id];
             $result['pasticchePrese'] = $stmt->rowCount();
             $result['pasticchePrescritte'] = $pasticchePrescritte;
             $result['error'] = true;
             $result['message'] = 'La prescrizione non è stata seguita correttamente.';
           }

         else
            {
             //problemi con l'esecuzione della query
             $result = null;
            }

         if($stmt2->rowCount() > 0)
            {
             $row = $stmt2->fetch(\PDO::FETCH_ASSOC);

             $result['id_paziente'] = $row['id_paziente'];
            }

         return $result;
        }


    public function getNumero_Pasticche($args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $id = implode(',', array_keys($args));
        
         // decodifica l'ID che viene passato in base 64
         //$args[$id] = base64_decode($args[$id]);

         $sql= "SELECT numero_pasticche FROM prescrizione WHERE  " . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
  
         $stmt = $this->pdo->prepare($sql);

         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));

         $stmt->execute();

         if($stmt)
            {
             //query andata a buon fine quindi mi restituisce il numero di pasticche che vado a salvare in una varibile         
             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {
                 $result = $row['numero_pasticche'];
                }
            }

         else
            {
             //problemi con l'esecuzione della query
             $result = null;
            }

         return $result;
        }


     public function getQuestionario($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
         $table = $this->maintable != '' ? $this->maintable : $path;
         
         $id = implode(',', array_keys($args));
        
         // decodifica l'ID del paziente che viene passato in base 64
         $args[$id] = base64_decode($args[$id]);

         if($table=='esas')
            {
             $id_questionario='id_esas';
            }

         else
            {
             $id_questionario='id_ctcae';
            }

         $sql = "SELECT " . $id_questionario ." FROM ". $table ." WHERE DATEDIFF(now(),data_compilazione)<4 AND " . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
 
         $stmt = $this->pdo->prepare($sql);

         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));

         $stmt->execute();
         //query che restituisce l'id dei questionari di quel relativo paziente la cui data di compilazione è minore di 4 giorni fa.
         //se contiene anche solo un valore significa che l'ultimo questionario risale a meno di 4 giorni fa quindi ok
         //se è vuoto si deve notificare di compilare il questionario

         if($stmt)
            {
             //query andata a buon fine 
             $result= array();
            
             if($stmt->rowCount() > 0)
                {
                 $result['error'] = false;
                 $result['id_paziente'] = $args[$id];
                 $result['message'] = 'Nessuna notifica';
                }
                 
             else
                {                
                 $result['error'] = true;
                 $result['id_paziente'] = $args[$id];
                 $result['message'] = 'L\'ultimo questionario e stato compilato più di 4 giorni fa';
                }
            }

         else
            {
             //problemi con l'esecuzione della query
             $result = null;
            }

         return $result;
        }


     public function getVerificaQuestionario($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
         $table = $this->maintable != '' ? $this->maintable : $path;
         
         $id = implode(',', array_keys($args));
        
         // decodifica l'ID che viene passato in base 64
         $args[$id] = base64_decode($args[$id]);
        
         if($table == 'esas')
            {
             //$id_questionario='id_esas';
             $sql = "SELECT id_paziente, " . $id ." FROM ". $table ." WHERE (dolore>=7 OR attivita>=7 OR nausea>=7 OR depressione>=7 OR ansia>=7 OR appetito>=7 OR benessere>=7 OR fatica_respiro>=7 OR sonnolenza>=7) AND " . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
            }

         else
            {
             // $id_questionario='id_ctcae';
             $sql = "SELECT id_paziente, " . $id ." FROM ". $table ." WHERE (diarrea='g3' OR diarrea='g4' OR infiammazione_della_bocca='g3' OR infiammazione_della_bocca='g4' OR vomito='g3' OR vomito='g4' OR affanno='g3' OR affanno='g4' OR tosse='g3' OR tosse='g4' OR sindrome_mano_piedi='g3' OR sindrome_mano_piedi='g4' OR ipertensione='g3' OR ipertensione='g4' OR nausea='g3' OR nausea='g4' OR mancanza_di_appetito='g3' OR mancanza_di_appetito='g4' OR debolezza='g3' OR debolezza='g4' OR eruzioni_cutanee='g3' OR eruzioni_cutanee='g4' OR febbre='g3' OR febbre='g4') AND " . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
            }

         $stmt = $this->pdo->prepare($sql);

         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));
         
         $stmt->execute();
         //query che restituisce l'id dei questionari di quel relativo paziente la cui data di compilazione è minore di 4 giorni fa.
         //se contiene anche solo un valore significa che l'ultimo questionario risale a meno di 4 giorni fa quindi ok
         //se è vuoto si deve notificare di compilare il questionario
         if($stmt)
            {
             //query andata a buon fine 
             $result = array();

             if($stmt->rowCount() > 0)
                {
                 $row = $stmt->fetch(\PDO::FETCH_ASSOC);

                 $result['id_paziente'] = $row['id_paziente'];
                 $result[$id] = $row[$id];
                 $result['error'] = true;
                 $result['message'] = 'Ci sono valori allarmanti';
                }

             else
                {
                 $result['error'] = false;
                 $result['message'] = 'Tutti i valori nella norma'; 
                }
            }

         else
            {
             //problemi con l'esecuzione della query
             $result = null;
            }

         return $result;
        }


     /**
      * @return array
      */
     public function getAll($path, $arrparams)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__); 

         $table = $this->maintable != '' ? $this->maintable : $path;

         $select = "*";
         $orderby = "";
         $where = "";
       		 								 
        
            
         foreach($arrparams as $key => $value)
            {
        	 if($key = "sort")
                {
        		 $orderby = " ORDER BY " . $value;
        		 break;
        	    }
            }
            
         if($table=='questionario')
         {
            $orderby = " ORDER BY id_questionario DESC";
         }   
            

         $stmt = $this->pdo->prepare('SELECT '. $select .' FROM '.$table.$where.$orderby);
         $stmt->execute();

         // se la query va a buon fine
         if($stmt)
            {
             $result = array();
             
             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {
                 $result[] = $row;
                }
            }

         // se la query non va a buon fine
         else
            {
        	 $result = null;
            }

         return $result;
        }


     /**
      * @return array
      */
     public function getAllEsasByIdMedico($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__); 

         $id = implode(',', array_keys($args));
        
         // decodifica l'ID del medico che viene passato in base 64
         $id_medico = base64_decode($args[$id]);
		 
         // Trova gli ID degli ESAS compilati negli ultimi 7 giorni dai pazienti del medico attuale
         $stmt = $this->pdo->prepare("SELECT esas.id_esas FROM esas,users WHERE users.id=esas.id_paziente AND users.id_medico='$id_medico' AND DATEDIFF(now(),esas.data_compilazione)<7");

         $stmt->execute();

         if($stmt)
            {
             $result = array();
             
             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {
                 $result[] = $row;
                }
            }

         else
            {
             $result = null;
            }

         return $result;
        }


     /**
      * @return array
      */
     public function getAllCtcaeByIdMedico($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__); 

         $id = implode(',', array_keys($args));
        
         // decodifica l'ID del medico che viene passato in base 64
         $id_medico = base64_decode($args[$id]);

         // Trova gli ID dei CTCAE compilati negli ultimi 7 giorni dai pazienti del medico attuale
         $stmt = $this->pdo->prepare("SELECT ctcae.id_ctcae FROM ctcae,users WHERE users.id=ctcae.id_paziente AND users.id_medico='$id_medico' AND DATEDIFF(now(),ctcae.data_compilazione)<7");

         $stmt->execute();

         if($stmt)
            {
             $result = array();
             
             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {
                 $result[] = $row;
                }
            }

         else
            {
             $result = null;
            }

         return $result;
        }


     /**
      * @return array
      */
     public function getAllAlarmsByIdMedico($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__); 

         $id = implode(',', array_keys($args));
        
         // decodifica l'ID del medico che viene passato in base 64
         $id_medico = base64_decode($args[$id]);

         // Trova tutti gli allarmi relativi ai pazienti del medico attuale
         $stmt = $this->pdo->prepare("SELECT alarm_messages.* FROM alarm_messages,users WHERE users.id=alarm_messages.id_paziente AND users.id_medico='$id_medico'");

         $stmt->execute();

         if($stmt)
            {
             $result = array();
             
             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {
                 $result[] = $row;
                }
            }

         else
            {
             $result = null;
            }

         return $result;
        }

    
     /**
      * @param int $id
      *
      * @return one object
      */
     public function get($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path;

         $select = "*";

         $orderby = "";
         // un paziente è uno user che ha l'id_medico diverso da 0
         // (la tabella paziente non esiste più per motivi di privacy)
         // Sempre per motivi di privacy, dalla tabella users posso ottenere solo l'ID, l'id_medico, il tipo_utente
         // ed il registration_code per verificare se l'account è attivo o no
         if($table == "paziente" || $table == "users")
            {
             $select = "id, id_medico, tipo_utente, registration_code, raccordo_anamnestico";
             $table = "users";
            }

         else if($table == "gcmtoken")
            {
             $select = "gcm_token";
             $table = "users";
            }

         else if($table == "appuntamento")
            {
            	$orderby = " ORDER BY data ASC";
            }
         
         $id = implode(',', array_keys($args));
        
         // decodifica l'ID che viene passato in base 64
         $args[$id] = base64_decode($args[$id]);

         //$sql = "SELECT ". $select ." FROM ". $table . ' WHERE ' . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
         $sql = "SELECT ". $select ." FROM ". $table . ' WHERE ' . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args)) . $orderby;
         
         
         $stmt = $this->pdo->prepare($sql);

         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));

         $stmt->execute();

         if($stmt)
            {
             $result = array();
             
             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {	
                 $result[] = $row;
                }
            }

         else
            {
             $result = null;
            }

         return $result;
        }


     public function getPatologiePaziente($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path;

         $id = implode(',', array_keys($args));
        
         // decodifica l'ID che viene passato in base 64
         $args[$id] = base64_decode($args[$id]);

         $sql = "SELECT * FROM patologie_pazienti, patologia WHERE patologie_pazienti.id_patologia=patologia.id_patologia AND " . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
  
         $stmt = $this->pdo->prepare($sql);

         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));

         $stmt->execute();

         if($stmt)
            {
             $result = array();
             
             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {
                 $result[] = $row;
                }
            }

         else
            {
             $result = null;
            }

         return $result;
        }


    public function getPrescrizioniPaziente($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path;

         $id = implode(',', array_keys($args));
        
         // decodifica l'ID che viene passato in base 64
         $args[$id] = base64_decode($args[$id]);
		
         $sql = "SELECT * FROM prescrizione, farmaco WHERE prescrizione.id_farmaco=farmaco.id_farmaco AND " . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
  
         $stmt = $this->pdo->prepare($sql);
         
         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));

         $stmt->execute();

         if($stmt)
            {
             $result = array();
             
             while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
                {
                 $result[] = $row;
                }
            }

         else
            {
             $result = null;
            }

         return $result;
        }


     //path=users e args=id e password
     public function Access_token($args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         // seleziona un access_token ancora valido
         $sql = "SELECT access_token FROM oauth_access_tokens WHERE user_id = $args && expires > now()";

         $stmt = $this->pdo->prepare($sql);        

         $stmt->bindValue(':user_id' , $args);

         $stmt->execute();

         if($stmt)
            {
             $result = $stmt->fetch(\PDO::FETCH_ASSOC);
            }

         else
            {
             $result = null;
            }

         return $result;
        }


     public function Refresh_token($args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $sql = "SELECT refresh_token FROM oauth_refresh_tokens WHERE user_id = $args";

         $stmt = $this->pdo->prepare($sql);        

         $stmt->bindValue(':user_id' , $args);

         $stmt->execute();

         if($stmt)
            {
             $result = $stmt->fetch(\PDO::FETCH_ASSOC);
            }

         else
            {
             $result = null;
            }

         return $result;
        }


     public function Credentials_Oauth($args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
		 
         $sqlquery = "SELECT tipo_utente FROM users WHERE users.id=$args";
         
         $stmtquery = $this->pdo->prepare($sqlquery);
         
         $stmtquery->bindValue(':user_id', $args);
         
         $stmtquery->execute();
         
         if($stmtquery)
         {
         	$resultquery = $stmtquery->fetch(\PDO::FETCH_ASSOC);
         	if(strcasecmp($resultquery['tipo_utente'], "paziente") == 0)
         	{
         		$sql = "SELECT client_id, client_secret, grant_types, tipo_utente, id_medico, scope, api_key, gcm_token, iv, salt FROM oauth_clients, users WHERE user_id = $args AND users.id=$args";
         	}
         	if((strcasecmp($resultquery['tipo_utente'], "medico") == 0))
         	{
         		$sql = "SELECT client_id, client_secret, grant_types, tipo_utente, users.id_medico, scope, api_key, gcm_token, iv, salt, medico.nome_medico, medico.cognome_medico FROM oauth_clients, users, medico WHERE user_id=$args AND users.id=$args AND medico.id_medico=$args";
         	}
         }
         
         //$sql = "SELECT oauth_clients.client_id, client_secret, grant_types, tipo_utente, users.id_medico, oauth_clients.scope, api_key, gcm_token, iv, salt, medico.nome_medico, medico.cognome_medico, expires FROM oauth_clients, users, medico, oauth_access_tokens WHERE oauth_clients.user_id=$args AND oauth_access_tokens.user_id=$args AND users.id=$args AND medico.id_medico=users.id_medico ORDER BY expires DESC LIMIT 1";
		
         
         $stmt = $this->pdo->prepare($sql);        

         $stmt->bindValue(':user_id', $args);

         $stmt->execute();
		 
         if($stmt)
            {
            	
             $result = $stmt->fetch(\PDO::FETCH_ASSOC);

             // se l'utente è di tipo paziente
             if(strcasecmp($result['tipo_utente'], "paziente") == 0)
                {
                 // trova i dati necessari dalla tabella paziente
                 // (non più necessario, i dati del paziente non sono salvati nel DB per privacy)
                 //$sql = "SELECT nome, cognome FROM users WHERE id_paziente = $args";
                 
                $sql = "SELECT * FROM users WHERE id = $args";
                	
                 $stmt = $this->pdo->prepare($sql);        

                 //$stmt->bindValue(':id_paziente', $args);
                 $stmt->bindValue(':id', $args);

                 $stmt->execute();

                 $user = $stmt->fetch(\PDO::FETCH_ASSOC);

                 $result =array_merge($result, $user);
                 
                }

             // se l'utente è di tipo admin
             else if(strcasecmp($result['tipo_utente'], "admin") == 0)
                {
                 // trova i dati necessari dalla tabella paziente
                 // (non più necessario, i dati del paziente non sono salvati nel DB per privacy)
                 /*$sql = "SELECT nome, cognome FROM paziente WHERE id_paziente = $args";

                 $stmt = $this->pdo->prepare($sql);        

                 $stmt->bindValue(':id_paziente', $args);

                 $stmt->execute();

                 $user = $stmt->fetch(\PDO::FETCH_ASSOC);

                 $result =array_merge($result, $user);*/
                }

             // se l'utente è di tipo medico
             else if(strcasecmp($result['tipo_utente'], "medico") == 0)
                {
                 // trova i dati necessari dalla tabella medico
                 $sql = "SELECT nome_medico, cognome_medico FROM medico WHERE id_medico = $args";

                 $stmt = $this->pdo->prepare($sql);        

                 $stmt->bindValue(':id_medico', $args);

                 $stmt->execute();

                 $user = $stmt->fetch(\PDO::FETCH_ASSOC);

                 // unisce i nuovi risultati ai precedenti
                 $result = array_merge($result, $user);
                }

             // tipo utente non riconosciuto
             else
                {
                 $result = null;
                }
            }
         
         // errore nella query principale
         else
            {
             $result = null;
            }
 
         return $result;
        }


    public function getAccessTokenExpirationTime($id)
        {      
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
  
         $stmt = $this->pdo->prepare("SELECT expires FROM oauth_access_tokens WHERE user_id = $id ORDER BY expires DESC LIMIT 1");
        
         $stmt->execute(array('id' => $id));
   
         if(!$expirationTime = $stmt->fetch(\PDO::FETCH_ASSOC))
            {
             return false;
            }

         return $expirationTime;
        }


     public function getGcmToken($id)
        {      
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
  
         $stmt = $this->pdo->prepare("SELECT gcm_token FROM users  WHERE id = $id");
        
         $stmt->execute(array('id' => $id));
   
         if(!$gcmToken = $stmt->fetch(\PDO::FETCH_ASSOC))
            {
             return false;
            }

         return $gcmToken;
        }


     public function setUserPassword($userID)
        {
         if($user = $this->getUser($userID))
            {
             //$userID = base64_decode($userID);
			 
             // genera una nuova password e criptala
             $password = $this->generatePassword();
             $encryptedPassword = hash('sha256', $user['salt'].$password);

             $passwords['normal'] = $password;
             $passwords['encrypted'] = $encryptedPassword;
			 
             // aggiorna la password per l'utente
             $sql = "UPDATE users SET password='".$encryptedPassword."' WHERE id = ".$userID;
            
             $stmt = $this->pdo->prepare($sql);

             $stmt->execute();

             // se l'update è andato a buon fine
             if($stmt->rowCount() == 1)
                {
                 return $passwords;
                }

             else
                {
                 return null;
                }
            }
        }


     public function unsetRegistrationCode($userID)
        {
         if($user = $this->getUser($userID))
            {
             // imposta il registration_code a NULL
             $sql = "UPDATE users SET registration_code=NULL WHERE id = ".$userID;
            
             $stmt = $this->pdo->prepare($sql);

             $stmt->execute();

             // se l'update è andato a buon fine
             return ($stmt->rowCount() == 1) ? true : false;
            }
        }


     public function checkUserCredentials($id, $password)
        {
         if($user = $this->getUser($id))
            {
             	return $this->checkPassword($user, $password);
            }

         return false;
        }

     //ANDREA: This function has the aims to evaluate the state (valid or not) of the session   
     public function sessionVerification($id, $token)
     {
      if($user = $this->getUser($id))
      {
       return $this->validateToken($id, $token);
      }
        
      return false;
     }   

     //ANDREA: This function has the aims to validate if a valid access token already exists for a certain user
     protected function validateToken($id, $token)
     {
     	$this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
     
     	$sql = "SELECT access_token FROM oauth_access_tokens WHERE user_id = $id && access_token = $token && expires > now()";
     
     	$stmt = $this->pdo->prepare($sql);
     
     	$stmt->bindValue(':user_id' , $id);
     
     	$stmt->execute();
     
     	if($stmt)
     	{
     		return true;
     	}
        
     	return false;
     }
     
     
     protected function checkPassword($user, $password)
        {  
         $encryptedPassword = md5($password);
		 return strcasecmp($user['password'], $encryptedPassword) == 0;
        }


     public function checkUserFirstCredentials($id, $regCode)
        {
         if($user = $this->getUser($id))
            {
             return $this->checkRegistrationCode($user, $regCode);
            }

         return false;
        }


     protected function checkRegistrationCode($user, $regCode)
        {  
         // la password arriva già con hash
         //$password_hash = hash('sha256', $password);

         // return $user['password'] == ($password);
         //non fa confronto tra maiuscole e minuscole
         //$sanitizedData = filter_var($regCode, FILTER_SANITIZE_STRING);

         $encryptedRegCode = hash('sha256', $user['salt'].base64_decode($regCode));
         //$encryptedRegCode = $this->fnEncrypt($regCode, $user['id'], $user['iv']);

         return strcasecmp($user['registration_code'], $encryptedRegCode) == 0;
        }


     public function getUser($id)
        {      
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
  		 
         $stmt = $this->pdo->prepare("SELECT * FROM admin WHERE username = '$id'");
		 
         $stmt->execute(array('username' => $id));
   
         if(!$userInfo = $stmt->fetch(\PDO::FETCH_ASSOC))
            {     	   
             return false;
            }

         return $userInfo;
        }


     public function generateID()
        {
         $id=rand(100000, 999999);
        
         while($this->isUsersExists($id))
            {
             $id=rand(100000, 999999);
            }

         return $id;
        }


     public function generatePatientID($tempID)
        {
         $id = rand(1000, 9999);

         $finalID = $id.$tempID;
        
         while($this->isUsersExists($finalID))
            {
             $id = rand(1000, 9999);

             $finalID = $id.$tempID;     
            }

         return $finalID;
        }


     private function isUsersExists($id)
        {
         $stmt = $this->pdo->prepare("SELECT id FROM users WHERE id = $id");
         $stmt->bindValue(":id", $id);
         $stmt->execute();
         $row = $stmt->fetch(\PDO::FETCH_ASSOC);

         $result=$row > 0;
         
         return $result;
        }


     // Genera un ID unico di 6 cifre per l'ospedale, controllando che non esista già
     public function generateIdOspedale()
        {
         $id = rand(100000, 999999);
        
         while($this->isOspedaleExists($id))
            {
             $id = rand(100000, 999999);
            }

         return $id;
        }


     // Controlla se esiste già un ospedale con l'id passato per parametro
     private function isOspedaleExists($id)
        {
         $stmt = $this->pdo->prepare("SELECT id_ospedale FROM ospedale WHERE id_ospedale = $id");
         $stmt->bindValue(":id_ospedale", $id);
         $stmt->execute();
         $row = $stmt->fetch(\PDO::FETCH_ASSOC);

         $result = $row > 0;
         
         return $result;
        }


     private function generatePassword($l = 9)
        {
         $chars  = '123456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
         $string = '';

         for($i = 0; $i < $l; $i++)
            {
             $string .= $chars[rand(0, strlen($chars) - 1)];
            }

         return $string;
        }


     private function generateKey()
        {
         return md5(uniqid(rand(), true));
        }


     private function generateClientId($id)
        {
         return 'iCARE' . $id;
        }

    
     private function generateClientSecret()
        {
         return uniqid(rand(), false);
        }


     /**
      * @param array $request_data
      *
      * @return int (last inserted id)
      */
     public function add($path, $request_data)
        {  
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path;
         
         
         if($request_data == null)
            {
             // La add appuntamento si blocca qui perch� request data � null
             return false;
            }
       
         //$columnString = implode(',', array_flip($request_data));
         //$valueString = ":".implode(',:', array_flip($request_data));

            
         $valueString = ":".implode(',:', array_keys($request_data));
         $columnString = implode(',', array_keys($request_data));

         $sql = "INSERT INTO " . $table . " ("  . $columnString . ") VALUES (" . $valueString . ")";

         $stmt = $this->pdo->prepare($sql);
		 
         foreach($request_data as $key => $value)
            {
             // sanitize data (already done by prepare(), but just to be sure)
             $sanitizedData = filter_var($request_data[$key], FILTER_SANITIZE_STRING);
            
             $stmt->bindValue(':' . $key, $sanitizedData);
            }

         if($stmt->execute())
            { 
                 return $this->pdo->lastInsertId();
            }
           
        }


     public static function unique_salt()
        {
         return substr(sha1(mt_rand()), 0, 16);
         // return hash('sha256', substr((mt_rand(), 0, 16)));
        }


     // Questa funzione cifra tutti i dati che gli vengono passati.
     /*public function addPaziente($path, $request_data)
        {   
         //require_once '../Utils/fnEncrypt.php'; //percorso sbagliato.. per ora la funzione fnEcrypt è quella dichiarata subito dopo di questa..

         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path;//table=paziente

         if($request_data == null)
            {
             return false;
            }

         $id_paziente = $this->generateID();
         $password = $this->generatePassword();
        
         $iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND);

         $salt = $this->unique_salt();

         $UsersData['id'] = $id_paziente;
         $UsersData['api_key'] = $this->generateKey();
         $UsersData['tipo_utente'] = 'paziente';
         $UsersData['iv'] = $iv;
         // $UsersData['password']= hash('sha256', $password);
         $UsersData['password'] = hash('sha256', $salt . $password);
         $UsersData['salt'] = $salt;
     
         $path1 = 'users';

         $users = $this->add($path1, $UsersData);

         $ClientData['client_id'] = $this->generateClientId($id_paziente);

         $ClientData['client_secret'] = $this->generateClientSecret();
         $ClientData['grant_types'] = 'password';
         //$ClientData['redirect_uri']='';
         $ClientData['scope'] = 'basic';
         $ClientData['user_id'] = $id_paziente;
         $path2 = 'oauth_clients';

         $client = $this->add($path2, $ClientData);

         if(!$users && !$client)
            {
             return false;
            }

         //$iv=mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND);
         //$request_data['iv']=$iv;
         $request_data['id_paziente'] = $id_paziente;
         $columnString = implode(',', array_flip($request_data));
         $valueString = ":".implode(',:', array_flip($request_data));
      
         $sql = "INSERT INTO " . $table . " (" . $columnString . ") VALUES (" . $valueString . ")";
         $stmt = $this->pdo->prepare($sql);

         foreach($request_data as $key => $value)
            {
             if($sanitizedData = filter_var($request_data[$key], FILTER_SANITIZE_STRING))
                { 
                 if($key != 'id_paziente' && $key != 'id_medico')// && $key != 'iv')
                    {
                     // if($key=='telefono'){
                     //  $sanitizedData=pack("L", $sanitizedData);
                     //}

                     $stmt->bindValue(':' . $key, $this->fnEncrypt($sanitizedData,$request_data['id_paziente'],$iv));
                    }

                 else
                    {
                     $stmt->bindValue(':' . $key, $sanitizedData);
                    }
                }
            }
        
         if($stmt->execute())
            {
             $result = array();
             $result['id_paziente'] = $id_paziente;
             $result['password'] = $password;
            }

         else
            {
             return null;
            }

         //Restituisce tutti i dati del pazienti compresi id e password.
         return $result;
        }*/


    public function addUser($path, $request_data)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path; // table=paziente

         if($request_data == null)
            {
             return null;
            }

         // se è un utente di tipo paziente
         if(strcasecmp($request_data['tipo_utente'], "paziente") == 0)
            {// L'ID di un paziente sarà composto da una stringa univoca di 4 cifre generata dal sistema
             // più una stringa numerica inserita dal medico (codice della cartella clinica del paziente)
             $generatedIDPart = $this->generatePatientID($request_data['id']);

             $request_data['id'] = $generatedIDPart;

             $UsersData['id'] = $request_data['id'];
             $UsersData['id_medico'] = $request_data['id_medico'];
             if (isset($request_data['raccordo_anamnestico']))
             	{
             	  $UsersData['raccordo_anamnestico'] = $request_data['raccordo_anamnestico'];
             	}  
            }

         // se è un utente di tipo medico
         else if(strcasecmp($request_data['tipo_utente'], "medico") == 0)
            {
             $UsersData['id'] = $this->generateID();
             $UsersData['id_medico'] = 0;
            }

         // se è un utente di tipo admin o di un tipo non riconosciuto
         else
            {
             return null;
            }

         $UsersData['tipo_utente'] = $request_data['tipo_utente'];
       
         // --- Generation of keys --- //
         //$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND);
         //$UsersData['iv'] = $iv;

         $salt = $this->unique_salt();
         $UsersData['salt'] = $salt;
         
         $UsersData['api_key'] = $this->generateKey();
         
         $registration_code = $this->generatePassword();
         $UsersData['registration_code'] = hash('sha256', $salt.$registration_code);
         
         // Generate data for OAuth2
         $ClientData['client_id'] = $this->generateClientId($UsersData['id'].$UsersData['id_medico']);

         $ClientData['client_secret'] = $this->generateClientSecret();
         $ClientData['grant_types'] = 'refresh_token password';
         //$ClientData['redirect_uri'] = '';

         // se è un utente di tipo paziente
         if(strcasecmp($request_data['tipo_utente'], "paziente") == 0)
            {
             $ClientData['scope'] = 'basic';
            }

         // se è un utente di tipo medico
         else if(strcasecmp($request_data['tipo_utente'], "medico") == 0)
            { 
             $ClientData['scope'] = 'doctor';
            }

         // se è un utente di tipo admin o di un tipo non riconosciuto
         else
            {
             $ClientData['scope'] = 'admin';
            }

         $ClientData['user_id'] = $UsersData['id'];
       
         // Add data in "users" table
         $users = $this->add("users", $UsersData);
             
         // Add data in "oauth_clients" table
         $client = $this->add("oauth_clients", $ClientData);

         // se sia la query in "users" che quella in "oauth_clients" sono andate a buon fine
         if($users && $client)
            { 
             // se è un utente di tipo paziente
             if(strcasecmp($request_data['tipo_utente'], "paziente") == 0)
                {
                 // prepare the output result data (user's id and registration_code)
                 $result = array();
                 $result['id'] = $UsersData['id'];
                 $result['registration_code'] = $registration_code;
                 $result['last_inserted_user'] = $users;
                }

             // se è un utente di tipo medico
             else if(strcasecmp($request_data['tipo_utente'], "medico") == 0)
                {   
                 // elimina il campo non più necessario dall'array $request_data
                 unset($request_data['tipo_utente']);

                 $request_data['id_medico'] = $UsersData['id'];
    
                 //$medico= $this->add("medico", $request_data);
                 $columnString = implode(',', array_flip($request_data));
                 $valueString = ":" . implode(',:', array_flip($request_data));

                 $sql = "INSERT INTO medico (" . $columnString . ") VALUES (" . $valueString . ")";
                 $stmt = $this->pdo->prepare($sql);

                 foreach($request_data as $key => $value)
                    {
                     $sanitizedData = filter_var($request_data[$key], FILTER_SANITIZE_STRING);
                     
                     $stmt->bindValue(':' . $key, $sanitizedData);
                     
                     /*if($key != 'id' && $key != 'id_medico')
                        {
                         // salva i dati in modo criptato
                         $stmt->bindValue(':' . $key, $this->fnEncrypt($sanitizedData, $request_data['id_medico'], $iv));
                        }

                     else
                        {
                         $stmt->bindValue(':' . $key, $sanitizedData);
                        }*/
                    }

                 // se la query in "medico" è andata a buon fine
                   if($stmt->execute())
                    { 
                     // prepare the output result data (user's id and registration_code)
                     $result = array();
                     $result['id'] = $UsersData['id'];
                     $result['registration_code'] = $registration_code;
                    }

                 else
                    {
                     return null;
                    }

                 /*
                 $valueString = ":".implode(',:', array_keys($request_data));
                 $columnString = implode(',', array_keys($request_data));
                
                 //$table='medico';

                 // $sql = "INSERT INTO " . $table . " ("  . $columnString . ") VALUES (" . $valueString . ")";

                 $sql = "INSERT INTO medico (" . $columnString . ") VALUES (" . $valueString . ")";

                 $stmt = $this->pdo->prepare($sql);
 
                 foreach($request_data as $key => $value)
                    {
                     $sanitizedData = filter_var($request_data[$key], FILTER_SANITIZE_STRING);
                     
                     $stmt->bindValue(':'. $key, $sanitizedData);
                     
                     /*if($key != 'id' && $key != 'id_medico')
                        {
                         // salva i dati in modo criptato
                         $stmt->bindValue(':' . $key, $this->fnEncrypt($sanitizedData, $request_data['id_medico'], $iv));
                        }

                     else
                        {
                         $stmt->bindValue(':' . $key, $sanitizedData);
                        }*/
                  //  }

                 // se la query in "medico" è andata a buon fine
                 /* if($stmt->execute())
                    { 
                     // prepare the output result data (user's id and registration_code)
                     $result = array();
                     $result['id'] = $UsersData['id'];
                     $result['registration_code'] = $registration_code;
                    }

                 else
                    {
                     return null;
                    }
                 */
                }

             // se è un utente di tipo admin o di un tipo non riconosciuto
             else
                {
                 return null;
                }
            }

         // se la query in "users" o quella in "oauth_clients" non è andata a buon fine
         else
            {
             return null;
            }

         return $result;
        }


     // funzione di cifratura RIJNDAEL 256
     public function fnEncrypt($stringToBeEncrypted, $sSecretKey, $iv)
        {
         return rtrim
            (
             base64_encode
                (
                 mcrypt_encrypt
                    (
                     MCRYPT_RIJNDAEL_256,
                     md5($sSecretKey),
                     $stringToBeEncrypted,
                     MCRYPT_MODE_CBC,
                     //md5(md5($sSecretKey))
                     $iv
                    )
                ),

             "\0"
            );
        }


     // funzione di decifratura RIJNDAEL 256
     public function fnDecrypt($stringToBeDecrypted, $sSecretKey, $iv)
        {
         return rtrim
            (
             mcrypt_decrypt
                (
                 MCRYPT_RIJNDAEL_256,
                 md5($sSecretKey),
                 base64_decode($stringToBeDecrypted),
                 MCRYPT_MODE_CBC,
                 //md5(md5($sSecretKey))
                 $iv
                ),

             "\0"
            );
        }


     /**
      * @param array $request_data
      *
      * @return bool
      */
     public function update($path, $args, $request_data)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path;
       	 
         // if no data to update or not key set = return false
         if($request_data == null || !isset($args[implode(',', array_flip($args))]))
            {
             return false;
            }

         $sets = 'SET ';

         foreach($request_data as $key => $value)
            {
             $sets = $sets . $key . ' = :' . $key . ', ';
            }

         $sets = rtrim($sets, ", ");

         $id = implode(',',array_keys($args));
        
         $args[$id] = base64_decode($args[$id]);

         $sql = "UPDATE ". $table . ' ' . $sets . ' WHERE ' . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
        
         $stmt = $this->pdo->prepare($sql);

         foreach($request_data as $key => $value)
            {
            if ($request_data[$key]=='reactivation')
            {
            		$stmt->bindValue(':' . $key,NULL);
            }
            else
            { 	
             $stmt->bindValue(':' . $key,$request_data[$key]);
            }
            }
  
         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));

         $stmt->execute();

      	 return ($stmt->rowCount() == 1) ? true : false;
        }

	 // sospensione account paziente
     public function sospendi($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path;
         //$request_data['password']=null;
         //$salt = $this->unique_salt();
         //$request_data['salt'] = $salt;
         $registration_code=$this->generatePassword();

         $request_data['registration_code'] = hash('sha256', $salt.$registration_code);

         // if no data to update or not key set = return false
         if($request_data == null || !isset($args[implode(',', array_flip($args))]))
            {
             return false;
            }

         $sets = 'SET ';

         foreach($request_data as $key => $value)
            {
             $sets = $sets . $key . ' = :' . $key . ', ';
            }

         $sets = rtrim($sets, ", ");

         $id = implode(',',array_keys($args));
        
         $args[$id] = base64_decode($args[$id]);

         $sql = "UPDATE ". $table . ' ' . $sets . ' WHERE ' . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
        
         $stmt = $this->pdo->prepare($sql);

         foreach($request_data as $key => $value)
            {
             $stmt->bindValue(':' . $key,$request_data[$key]);
            }
  
         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));

         $stmt->execute();

         $result['registration_code'] = $registration_code;

         return $result;
        }


     /**
      * @param int pk
      *
      * @return bool
      */
     public function delete($path, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $table = $this->maintable != '' ? $this->maintable : $path;
		 
         
         $sql = "DELETE FROM ". $table . ' WHERE ' . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
        
         $stmt = $this->pdo->prepare($sql);
         
         // bind the key
         $stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));
         $stmt->execute();

      	 return ($stmt->rowCount() > 0) ? true : false;
        }
        

        // delete patologie / prescrizioni
        public function deletePatologiePrescrizioni($path, $args)
        {
        	
        	$this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
        
        	$table = $this->maintable != '' ? $this->maintable : $path;
        	
        	 
        	$sql = "DELETE FROM ". $table . ' WHERE id_patologia=' .$args["id_patologia"]. ' AND id_paziente=' .$args["id_paziente"]. ' AND id_prescrizione=' .$args["id_prescrizione"];
        	
        
        	$stmt = $this->pdo->prepare($sql);
        	 
        	// bind the key
        	$stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));
        	$stmt->execute();
        
        	return ($stmt->rowCount() > 0) ? true : false;
        }
        
        
        
        //ANDREA: This is the function that serves queries for the DB (related on the searches)
        
        /**
         * @return array
         */
        public function getTupleSearch($arrparams)
        {
        	//var_dump($arrparams);
        	//die();
        	
        	$obj = $arrparams['obj'];
        	$key = $arrparams['keyword'];
        	$id = $arrparams['id'];
        	
        	
        	$select = "*";
        	$orderby = "";
        	$where = "";

        	switch ($obj)
        	{
        		case 'Pazienti':
        			$select = "id, registration_code";
        			$table = "users";
        			$where = " WHERE (id LIKE '%".$key."%') AND id_medico = ".$id."";
        			break;
        		
        		case 'Appuntamenti':
        			
        			$select = "id_appuntamento, id_paziente, data, ora, luogo, motivo";
        			$table = "appuntamento";
        			$where = " WHERE ((id_appuntamento LIKE '%".$key."%') OR (id_paziente LIKE '%".$key."%') OR (data LIKE '%".$key."%') OR (ora LIKE '%".$key."%') OR (luogo LIKE '%".$key."%') OR (motivo LIKE '%".$key."%')) AND (id_medico = ".$id.")";
        			break;

        		case 'Prescrizioni':
        			
        			$select = "id_prescrizione, id_paziente, data, id_farmaco, numero_pasticche, ora_assunzione, suggerimenti";
        			$table = "prescrizione";
        			$where = " WHERE ((id_prescrizione LIKE '%".$key."%') OR (id_paziente LIKE '%".$key."%') OR (id_farmaco LIKE '%".$key."%') OR (data LIKE '%".$key."%')) AND (id_medico = ".$id.")";
        			break;

        		case 'Patologie':
        			$select = "id_patologia, nome_patologia, descrizione";
        			$table = "patologia";
        			$where = " WHERE (id_patologia LIKE '%".$key."%') OR (nome_patologia LIKE '%".$key."%')";
        			break;

        		case 'Farmaco':
        			$select = "id_farmaco, nome, totale_compresse, posologia";
        			$table = "farmaco";
        			$where = " WHERE (id_farmaco LIKE '%".$key."%') OR (nome LIKE '%".$key."%')";
        			break;

        		case 'Questionari':
        			$select = "*";
        			$table = "ctcae";
        			$where = " WHERE (id_paziente LIKE '%".$key."%') OR (data_compilazione LIKE '%".$key."%')";
        			break;
        			
        		default:
        			echo "ERROR";
        			die();
        			
        	}
   
        	$stmt = $this->pdo->prepare('SELECT '. $select .' FROM '.$table.$where.$orderby);
        	$stmt->execute();
        
        	// se la query va a buon fine
        	if($stmt)
        	{
        		$result = array();
        		 
        		while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
        		{
        			$result[] = $row;
        		}
        	}
        
        	else
        	{
        		$result = null;
        	}
        
        	return $result;
        }
        
        
        
        public function setManaged($id, $class)
        {
        	
        	if($class == 0)
        	{
        		$sql = "UPDATE alarm_messages SET is_solved=1 WHERE id = ".$id;
        
        		$stmt = $this->pdo->prepare($sql);
        
        		$stmt->execute();
        
        		// se l'update è andato a buon fine
        		return ($stmt->rowCount() == 1) ? true : false;
        	}
        	else 
        	{
        		$sql = "UPDATE alarm_messages SET is_solved=0 WHERE id = ".$id;
        		
        		$stmt = $this->pdo->prepare($sql);
        		
        		$stmt->execute();
        		
        		// se l'update è andato a buon fine
        		return ($stmt->rowCount() == 1) ? true : false;
        	}
        }
        
        
        // Rigenerazione codice
        public function regenerateCode($path, $args)
        {
        	
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
		 
         $table = $this->maintable != '' ? $this->maintable : $path;
         
         //$request_data['password']=null;
         $salt = $this->unique_salt();
         $request_data['salt'] = $salt;
         $registration_code=$this->generatePassword();
		
         $request_data['registration_code'] = hash('sha256', $salt.$registration_code);
         
         // if no data to update or not key set = return false
         if($request_data == null || !isset($args[implode(',', array_flip($args))]))
            {
             return false;
            }

         $sets = 'SET ';

         foreach($request_data as $key => $value)
            {
             $sets = $sets . $key . ' = :' . $key . ', ';
            }
		
         $sets = rtrim($sets, ", ");
		 
         
         $id = implode(',',array_keys($args));
        
         //$args[$id] = base64_decode($args[$id]);

         //$sql = "UPDATE users SET registration_code='".$request_data['registration_code']."' WHERE id = ".$args[$id];
         $sql = "UPDATE users SET registration_code='".$request_data['registration_code']."', salt='".$salt."' WHERE id = ".$args[$id];
         
         $stmt = $this->pdo->prepare($sql);
            
         $stmt->execute();

         $result['registration_code'] = $registration_code;

         return $result;
        }
        
        
        // Prescrizioni-Patologie Paziente
        public function getPrescrizioni_Patologie($path, $args)
        {
        	$this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
        
        	$table = $this->maintable != '' ? $this->maintable : $path;
        
        	$id = implode(',', array_keys($args));
        
        	// decodifica l'ID che viene passato in base 64
        	$args[$id] = base64_decode($args[$id]);
        
        	$sql = "SELECT * FROM prescrizioni_patologie, patologia, prescrizione, farmaco WHERE prescrizioni_patologie.id_patologia=patologia.id_patologia AND prescrizioni_patologie.id_prescrizione=prescrizione.id_prescrizione AND prescrizione.id_farmaco=farmaco.id_farmaco AND prescrizioni_patologie." . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
        	//$sql = "SELECT * FROM prescrizioni_patologie WHERE prescrizioni_patologie.id_patologia=patologia.id_patologia AND prescrizioni_patologie.id_prescrizione=prescrizione.id_prescrizione AND prescrizione.id_farmaco=farmaco.id_farmaco AND prescrizioni_patologie." . implode(',', array_flip($args)) . ' = :' . implode(',', array_flip($args));
        	
        	$stmt = $this->pdo->prepare($sql);
        	
        	// bind the key
        	$stmt->bindValue(':' . implode(',', array_flip($args)), implode(',', $args));
        
        	$stmt->execute();
        
        	if($stmt)
        	{
        		$result = array();
        		 
        		while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
        		{
        			$result[] = $row;
        		}
        	}
        
        	else
        	{
        		$result = null;
        	}
        
        	return $result;
        }
        
        
        
        
        //aggiunta patologia/prescrizioni
        public function addPatologiaPrescrizione($path, $request_data)
        {
        	$this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
        
        	$table = $this->maintable != '' ? $this->maintable : $path; // table=paziente
        
        	
        	
        	
        	if($request_data == null)
        	{
        		return null;
        	}
        
        	
        	$columnString = implode(',', array_flip($request_data));
        	
        	$valueString = ":" . implode(',:', array_flip($request_data));
        	
        		
        	$sql = "INSERT INTO prescrizioni_patologie (" . $columnString . ") VALUES (" . $valueString . ")";
        	
        	
        	$stmt = $this->pdo->prepare($sql);
        
        	foreach($request_data as $key => $value)
        			{
        				$sanitizedData = filter_var($request_data[$key], FILTER_SANITIZE_STRING);
        				 
        				$stmt->bindValue(':' . $key, $sanitizedData);
       
        			}
        	
//         	var_dump($stmt);
//         	die();
        			
        	if($stmt->execute())
        			{
        				// prepare the output result data (user's id and registration_code)
        				$result = array();
        				$result['id'] = $this->pdo->lastInsertId();
        			}
        
        			else
        			{
        				return null;
        			}
        
        
        	return $result;
        }
        

        
        public function getAllMedicoEsas($path, $args)
        {
        	$this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
        
        	$id = implode(',', array_keys($args));
        
        	// decodifica l'ID del medico che viene passato in base 64
        	$id_medico = base64_decode($args[$id]);
        		
        	// Trova gli ID degli ESAS compilati negli ultimi 7 giorni dai pazienti del medico attuale
        	$stmt = $this->pdo->prepare("SELECT * FROM esas,users WHERE users.id=esas.id_paziente AND users.id_medico='$id_medico' AND DATEDIFF(now(),esas.data_compilazione)<7");
        
        	$stmt->execute();
        
        	if($stmt)
        	{
        		$result = array();
        		 
        		while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
        		{
        			$result[] = $row;
        		}
        	}
        
        	else
        	{
        		$result = null;
        	}
        
        	return $result;
        }
        
        
        
        /**
         * @return array
         */
        public function getAllMedicoCTCAE($path, $args)
        {
        	$this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
        
        	$id = implode(',', array_keys($args));
        
        	// decodifica l'ID del medico che viene passato in base 64
        	$id_medico = base64_decode($args[$id]);
        
        	// Trova gli ID dei CTCAE compilati negli ultimi 7 giorni dai pazienti del medico attuale
        	$stmt = $this->pdo->prepare("SELECT * FROM ctcae,users WHERE users.id=ctcae.id_paziente AND users.id_medico='$id_medico' AND DATEDIFF(now(),ctcae.data_compilazione)<7");
        
        	$stmt->execute();
        
        	if($stmt)
        	{
        		$result = array();
        		 
        		while($row = $stmt->fetch(\PDO::FETCH_ASSOC))
        		{
        			$result[] = $row;
        		}
        	}
        
        	else
        	{
        		$result = null;
        	}
        
        	return $result;
        }
        
        
        
    }

?>