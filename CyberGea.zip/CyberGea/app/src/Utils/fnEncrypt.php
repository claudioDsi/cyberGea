<?php

public function fnEncrypt($sValue, $sSecretKey, $iv)
	{
	 return rtrim
	 	(
		 base64_encode
		 	(
			 mcrypt_encrypt
			 	(
				 MCRYPT_RIJNDAEL_256,
				 $sSecretKey.$sSecretKey.$sSecretKey.$sSecretKey, $sValue, 
				 MCRYPT_MODE_CBC, 
				 $iv
				)
			),

		 "\0" 
		);
	}

?>