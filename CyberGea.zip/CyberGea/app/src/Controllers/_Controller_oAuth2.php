<?php

namespace App\Controllers;

use Psr\Log\LoggerInterface;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

use Symfony\Bridge\PsrHttpMessage\Factory\HttpFoundationFactory;
use OAuth2\HttpFoundationBridge\Request as BridgeRequest;

use App\Controllers\_Controller;
use App\DataAccess\_DataAccess;
use Slim\Views\Twig as View;

/**
 * Class _Controller_oAuth2
 */
class _Controller_oAuth2 extends _Controller
    {
     /**
      * @var oAuth2server
      */
     protected $oAuth2server;

     /**
      * @var user
      */
     protected $user;

     /**
      * @param \Psr\Log\LoggerInterface       $logger
      * @param \App\DataAccess                $dataaccess
      * @param                                $server
      */
     public function __construct(View $view,LoggerInterface $logger, _DataAccess $dataaccess, $server)
        {
         parent::__construct($view,$logger,$dataaccess);
         $this->oAuth2server = $server;
        }
    

    
     /**
      * @param \Psr\Http\Message\ServerRequestInterface $request
      * @param \Psr\Http\Message\ResponseInterface      $response
      * @param array                                    $next
      *
      * @return \Psr\Http\Message\ResponseInterface
      */
     public function validateToken($request)
        { 
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         // convert a request from PSR7 to hhtpFoundation
         $httpFoundationFactory = new HttpFoundationFactory();
         $symfonyRequest = $httpFoundationFactory->createRequest($request);
         $bridgeRequest = BridgeRequest::createFromRequest($symfonyRequest);
         
         if(!$this->oAuth2server->verifyResourceRequest($bridgeRequest))
            {
             $this->oAuth2server->getResponse()->send();
             die();
            }

         // store the user_id
         $token = $this->oAuth2server->getAccessTokenData($bridgeRequest);
        
         $this->user = $token['user_id'];

         return TRUE;
        }
   

     

     public function addUser(Request $request, Response $response, $args)
        {
         if($this->validateToken($request) && isset($this->user))
            {  
             return (parent::addUser($request, $response, $args));
            }
         else
            {
             return $response->withStatus(400);
            }
        }


     public function login(Request $request, Response $response, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $path = explode('/', $request->getUri()->getPath())[0];
  
         $request_data = $request->getParsedBody(); //contiene id e password

         // l'ID e la password mi vengono mandati codificati in base64, quindi devo decodificarli
         // (la decodifica della password viene fatta nella funzione checkUserCredentials())
         $request_data['id'] = base64_decode($request_data['id']);
        
         // controlla se userID e password sono corretti
         $login = $this->dataaccess->checkUserCredentials($request_data['id'], $request_data['password']);

         // se userID o password sono corrette
         if($login)
            { //gcm_token non presente
             if(!$gcm_token = $this->dataaccess->getGcmToken($request_data['id']))
                {
                 //Server Google lo deve assegnare
                }

             // cerca un access token ancora valido per l'utente, se esiste
             $access_token = $this->dataaccess->Access_token($request_data['id']);

             // se l'utente non ha un access token o ce l'ha scaduto
             if(!$access_token)
                {            
                 // trova client_id, client_secret e grant_type dell'utente dal DB più iv per il paziente e nome e cognome per il medico
                 $credentials = $this->dataaccess->Credentials_Oauth($request_data['id']);

                 // aggiungi id e password all'array
                 $credentials['id'] = $request_data['id'];
                 $credentials['password'] = $request_data['password'];
                 //$credentials['grant_type'] = $credentials['grant_types'];
                 $credentials['grant_type'] = "password";
                 unset($credentials['grant_types']);
 
                 // la password mi viene passata in base64, quindi devo decodificarla
                 // e poi calcolare lo sha256 con il salt
                 $credentials['password'] = hash('sha256', $credentials['salt'].base64_decode($credentials['password']));

                 $request->setParsedBodyParams($credentials);

                 $class = new _oAuth2TokenController($this->logger, $this->oAuth2server);

                 $token = $class->tokenForLogin($request, $response, $credentials);
        
                 // se l'utente non ha ottenuto un nuovo access token                
                 if(!$token)
                    {
                     $error = array();
                     $error['error'] = true;
                     $error['message'] = 'Assegnazione token non andata a buon fine';
                     
                     return $response->withJson($error, 500);

                     //$response->setError($statusCode, $error, $error_description, $error_uri);
                     //return $response->withJson('Assegnazione token non andata a buon fine', 500);
                    }

                 // se l'utente ha ottenuto correttamente un nuovo access token
                 else
                    { 
                     unset($credentials['id']);
                     unset($credentials['password']);

                     // take the expiration time for the just created access token
                     $expirationTimeArray = $this->dataaccess->getAccessTokenExpirationTime($request_data['id']);

                     $credentials = array_merge($credentials, $expirationTimeArray);

                     // se tutto è andato a buon fine, posso impostare error=false
                     $credentials['error'] = false;
      
                     $token->addParameters($credentials);
                     $token->send();
                     
                     /*
                     $_SESSION["token"]= $credentials['access_token'];
                     $_SESSION["nome_medico"] = $credentials['nome_medico'];
                     $_SESSION["cognome_medico"] = $credentials['cognome_medico'];
                     return $this->view->render($response, 'index.twig', $_SESSION);*/
                    }
                }

             // se l'utente ha un access token valido
             else
                {           
                 $refresh_token = $this->dataaccess->Refresh_token($request_data['id']);
                 $result = $this->dataaccess->Credentials_Oauth($request_data['id']);
                 // take the expiration time for the latest access token
                 $expirationTimeArray = $this->dataaccess->getAccessTokenExpirationTime($request_data['id']);

                 $result = array_merge($result, $access_token, $refresh_token, $expirationTimeArray);
               
                 // se tutto è andato a buon fine, posso impostare error=false
                 $result['error'] = false;
                 /*
                 $result2= array_merge($result,$request_data); //mi serve anche l'id per far visualizzare il profilo del medico
                 $_SESSION["token"]= $result['access_token'];
                 $_SESSION["nome_medico"] = $result['nome_medico'];
                 $_SESSION["cognome_medico"] = $result['cognome_medico'];
                 // devo visualizzare l'homepage passando come dati $result
                  return $this->view->render($response, 'index.twig', $_SESSION); 
                  */
                 return $response->withJson($result, 200);
                }
            }

         // se userID o password non erano corrette
         else
            {
             $error = array();
             $error['error'] = true;
             $error['message'] = 'UserId o password non corretti';
             
             //return $this->view->render($response, 'auth/login.twig', $error);
             return $response->withJson($error, 403);
            }
        }


     // needs an oAuth2 Client credentials grant
     // with Resource owner credentials grant also works 
     public function getAll(Request $request, Response $response, $args)
        {
        	
         if($this->validateToken($request))
            {
             parent::getAll($request, $response, $args);
            }
        
        }


     // needs an oAuth2 Client credentials grant
     // with Resource owner credentials grant also works
     public function get(Request $request, Response $response, $args)
        {
         if($this->validateToken($request))
            {
             parent::get($request, $response, $args);             
            }     
        }


     // needs an oAuth2 Resource owner credentials grant
     // checked with isset($this->user)
     public function add(Request $request, Response $response, $args)
        {
         
         if($this->validateToken($request) && isset($this->user))
            {
             return (parent::add($request, $response, $args));
            }
         else
            { 
             return $response->withStatus(400);
            }
        }

 
     public function addPaziente(Request $request, Response $response, $args)
        {
         if($this->validateToken($request) && isset($this->user))
            {
             return (parent::addPaziente($request, $response, $args));
            }

         else
            {
             return $response->withStatus(400);
            }
        }


     // needs an oAuth2 Resource owner credentials grant
     // checked with isset($this->user)
     public function update(Request $request, Response $response, $args)
        {	
         if($this->validateToken($request) && isset($this->user))
            {
             return (parent::update($request, $response, $args));
            }

         else
            {
             return $response->withStatus(400);
            }           
        }


 

     // needs an oAuth2 Resource owner credentials grant
     // checked with isset($this->user)
     public function delete(Request $request, Response $response, $args)
        {
         if($this->validateToken($request) && isset($this->user))
            {
             return (parent::delete($request, $response, $args));
            }
         
         else
            {
             return $response->withStatus(400);
            }           
        }
        
    }

?>