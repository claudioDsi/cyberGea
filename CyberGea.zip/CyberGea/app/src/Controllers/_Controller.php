<?php

namespace App\Controllers;

use Psr\Log\LoggerInterface;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

use App\DataAccess\_DataAccess;

use Slim\Views\Twig as View;
//use Slim\Flash as Flash;

include '_oAuth2TokenController.php';


/**
 * Class _Controller.
 */
class _Controller
    {
     //protected $flash;

     protected $view;
     /**
      * @var \Psr\Log\LoggerInterface
      */
     protected $logger;

     /**
      * @var \App\DataAccess
      */
     protected $dataaccess;


     /**
      * @param \Psr\Log\LoggerInterface       $logger
      * @param \App\DataAccess                $dataaccess
      */
     public function __construct(View $view, LoggerInterface $logger, _DataAccess $dataaccess)
        {
         $this->view = $view;
          //$this->flash = $flash;
         $this->logger = $logger;
         $this->dataaccess = $dataaccess;
        }
      	
        
      // ANDREA: This method has the aims to evaluate the possible/notpossible access to the area by a certain user.
      //         This choice is made on the state of the session.    
      public function session_already_started(Request $request, Response $response, $next) {

      	
      	
      	// FOR CURL
      	/*
      	if (!empty($request->getHeaders()['HTTP_SESSIONID'][0]))
      	{
      		parse_str($request->getHeaders()['HTTP_SESSIONID'][0],$array);

      		if(isset($array['session_id']) && isset($array['session_token']))
      		{ 
      			$session_validate = $this->dataaccess->sessionVerification($array['session_id'], $array['session_id']);
      			if ($session_validate)
      			{
      				$response = $next($request, $response);
      				return $response;
      			}
      			else
      			{
      				//$this->view->render($response, 'errorpage.twig',$array);
      				//return $response->withHeader('Content-type', 'text/html');
      				return $response->withStatus(302)->withHeader('Location', $request->getUri()->getBasePath().'/login');
      			}
      		}
      		else 
      		{
      			//$this->view->render($response, 'errorpage.twig',$array);
      			//return $response->withHeader('Content-type', 'text/html');
      			return $response->withStatus(302)->withHeader('Location', $request->getUri()->getBasePath().'/login');
      		}
      	}
      	
      	
      	
      		$arrparams = $request->getQueryParams();
      		
      		if (!empty($arrparams) && isset($arrparams['id']) && isset($arrparams['token']))
      		{
      			$session_validate = $this->dataaccess->sessionVerification($arrparams['id'], $arrparams['token']);
      			if ($session_validate)
      			{
      				$response = $next($request, $response);
      				return $response;
      			}
      			else 
      			{
      				//$this->view->render($response, 'errorpage.twig',$_SESSION);
      				//return $response->withHeader('Content-type', 'text/html');
      				return $response->withStatus(302)->withHeader('Location', $request->getUri()->getBasePath().'/login');
      			}		
      		}
      		*/
      	
        	if(isset($_SESSION['id']))
        	{
        			if ($request->getUri()->getPath() == 'login')
        			{
        				$this->view->render($response, 'homepage.twig',$_SESSION);
        				return $response->withHeader('Content-type', 'text/html');
        			}
        			$response = $next($request, $response);
        	}
        	else
        	{	
        		//ANDREA: Based on your preferences on redirections, adding or removing case (this is why we used SWITCH)
        		switch ($request->getUri()->getPath()) 
        		{
        			case 'home':
        				//$this->view->render($response, 'auth/login.twig',$_SESSION);
        				//return $response->withHeader('Content-type', 'text/html');
        				return $response->withStatus(302)->withHeader('Location', $request->getUri()->getBasePath().'/login');
        				break;
        				
        			default:
        				//$this->view->render($response, 'errorpage.twig',$_SESSION);
        				//return $response->withHeader('Content-type', 'text/html');
        				return $response->withStatus(302)->withHeader('Location', $request->getUri()->getBasePath().'/login');
        		}

         	}
        
        	return $response;
        	}

        	
        	public function login(Request $request, Response $response, $args)
        	{
        		$this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
        	
        		$path = explode('/', $request->getUri()->getPath())[0];
        	
        		$request_data = $request->getParsedBody(); //contiene id e password
        		
        		
        		// controlla se userID e password sono corretti
        		$login = $this->dataaccess->checkUserCredentials($request_data['id'], $request_data['password']);
        		
        		// se userID o password sono corrette
        		if($login)
        		{ 
        			//return $response->write(json_encode($login));
        			$data = array();
        			$data['login'] = $login;
        			return $response->withJson($data, 200);
        		}
        	
        		// se userID o password non erano corrette
        		else
        		{
        			$error = array();
        			$error['error'] = true;
        			$error['message'] = 'UserId o password non corretti';
        			 
        			//return $this->view->render($response, 'auth/login.twig', $error);
        			return $response->withJson($error, 403);
        		}
        	}    	
        	
        	
        	
    // ANDREA: This method has the aims to avoid login pages on a user already logged
    public function alreadylogged(Request $request, Response $response, $next) {
        	
        	
        if(isset($_SESSION['id']) && isset($_SESSION['token']))
        {
        	if ($request->getUri()->getPath() == 'login' || $request->getUri()->getPath() == 'firstlogin')
        	{
        	$session_validate = $this->dataaccess->sessionVerification($_SESSION['id'], $_SESSION['token']);
        	
        		if ($session_validate)
        		{
        			$this->view->render($response, 'index.twig',$_SESSION);
        			return $response->withHeader('Content-type', 'text/html');
        			
        		}
        		else
        		{
        			//$this->view->render($response, 'errorpage.twig',$_SESSION);
        			//return $response->withHeader('Content-type', 'text/html');
        			return $response->withStatus(302)->withHeader('Location', $request->getUri()->getBasePath().'/login');
        		}
        	}		
        }
        $response = $next($request, $response);
        
      	return $response;
        }   
     
     //funzione per mostrare la pagina di login
     public function loginIn(Request $request, Response $response, $args)
        {
         $this->view->render($response, 'auth/login.twig',$_SESSION);
	 
         if (isset($_SESSION["errorInfo"]))
         {
         	unset($_SESSION["errorInfo"]);
         }
         
         return $response->withHeader('Content-type', 'text/html');
        }

        	
     public function recuperoPassword(Request $request, Response $response, $args)
        {
        	$this->view->render($response, 'auth/notfound.twig',$_SESSION);
        
        	return $response->withHeader('Content-type', 'text/html');
        }   
       
        
     public function logout(Request $request, Response $response, $args)
        { 
         session_unset();
         session_destroy();
          
         $this->view->render($response, 'auth/login.twig');
         return $response->withHeader('Content-type', 'text/html');
        }


   



     /**
      * @param \Psr\Http\Message\ServerRequestInterface $request
      * @param \Psr\Http\Message\ResponseInterface      $response
      * @param array                                    $args
      *
      * @return \Psr\Http\Message\ResponseInterface
      */
     public function getAll(Request $request, Response $response, $args)
        {
         
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);
  
         $path = explode('/', $request->getUri()->getPath())[0];
         
         
         $arrparams = $request->getParams();
		
         $result = $this->dataaccess->getAll($path, $arrparams);
         
         if($result == null)
            {
             $error = array();
             $error['error'] = true;
             $error['message'] = 'No results found';
             
             //return $response->withJson($error, 404);
             return $response->write(json_encode($error));
            }

         else
            {
            	
             return $response->write(json_encode($result));
            }
        }


     /**
      * @param \Psr\Http\Message\ServerRequestInterface $request
      * @param \Psr\Http\Message\ResponseInterface      $response
      * @param array                                    $args
      *
      * @return \Psr\Http\Message\ResponseInterface
      */
     public function get(Request $request, Response $response, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $path = explode('/', $request->getUri()->getPath())[0];
     	
         // se sto richiedendo le patologie di un paziente, devo richiamare una funzione ad hoc che fa il join
         if($path == "patologie_pazienti" && sizeof($args) > 0)
            {
             $result = $this->dataaccess->getPatologiePaziente($path, $args);
            }
		 elseif ($path == "prescrizione" && sizeof($args) > 0)
            {
             $result = $this->dataaccess->getPrescrizioniPaziente($path, $args);
            }
         elseif ($path == "prescrizioni_patologie" && sizeof($args) > 0)
            {
            	$result = $this->dataaccess->getPrescrizioni_Patologie($path, $args);
            }   	
         else
            {
             $result = $this->dataaccess->get($path, $args);
            }
		 
         if($result == null)
            {
             $error = array();
             $error['error'] = true;
             $error['message'] = 'Not Found';
             
             //return $response->withJson($error, 404);
             return $response->write(json_encode($error));
            }

         else
            {
             return $response->write(json_encode($result));
            }
        }


     /**
      * @param \Psr\Http\Message\ServerRequestInterface $request
      * @param \Psr\Http\Message\ResponseInterface      $response
      * @param array                                    $args
      *
      * @return \Psr\Http\Message\ResponseInterface
      */
     public function add(Request $request, Response $response, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $path = explode('/', $request->getUri()->getPath())[0];
         $request_data = $request->getParsedBody();
         
         $last_inserted_id = $this->dataaccess->add($path, $request_data);
		 
         // se l'inserimento � andato a buon fine
         if($last_inserted_id > 0)
            {
             $RequesPort = '';
         
             if($request->getUri()->getPort()!='')
                {
                 $RequesPort = '.'.$request->getUri()->getPort();
                }

             $LocationHeader = $request->getUri()->getScheme().'://'.$request->getUri()->getHost().$RequesPort.$request->getUri()->getPath().'/'.$last_inserted_id;
             $result = array();
             $result['error'] = false;
             $result['message'] = 'Inserimento riuscito';
             $result['last'] = $last_inserted_id; 
             
             //return $response->withJson($result, 201); //->withHeader('Location', $LocationHeader) 
             return $response->write(json_encode($result));
            }

         else
            {	
             $error = array();
             $error['error'] = true;
             $error['message'] = 'Inserimento fallito';
             
             return $response->withJson($error, 403); 
            }
        }
        

     public function addUser(Request $request, Response $response, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $path = explode('/', $request->getUri()->getPath())[0];
         $request_data = $request->getParsedBody();

         $user = $this->dataaccess->addUser($path, $request_data);

         if($user != null)
            {
             return $response->withJson($user, 201);
                         /**->withHeader('Location', $LocationHeader)
                             ->withStatus(201);**/               
            }

         else
            {
             $error = array();
             $error['error'] = true;
            
             return $response->withJson($error, 403);
            }
        }


     /**
      * @param \Psr\Http\Message\ServerRequestInterface $request
      * @param \Psr\Http\Message\ResponseInterface      $response
      * @param array                                    $args
      *
      * @return \Psr\Http\Message\ResponseInterface
      */
     public function update(Request $request, Response $response, $args)
        {
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $path = explode('/', $request->getUri()->getPath())[0];
         $request_data = $request->getParsedBody();
         
		
         $isupdated = $this->dataaccess->update($path, $args, $request_data);
		 
         
         if($isupdated)
            {
             $result['error'] = false;
             $result['message'] = 'Update riuscito';
             
             return $response->write(json_encode($result));
             //return $response->withJson($result, 201);
            }

         else
            {
             $result['error'] = true;
             $result['message'] = 'Update fallito';
             
             return $response->write(json_encode($result));
             //return $response->withJson($result, 304); 
            }
        }

     /**
      * @param \Psr\Http\Message\ServerRequestInterface $request
      * @param \Psr\Http\Message\ResponseInterface      $response
      * @param array                                    $args
      *
      * @return \Psr\Http\Message\ResponseInterface
      */
     public function delete(Request $request, Response $response, $args)
        {
        	
         $this->logger->info(substr(strrchr(rtrim(__CLASS__, '\\'), '\\'), 1).': '.__FUNCTION__);

         $path = explode('/', $request->getUri()->getPath())[0];
         
         $isdeleted = $this->dataaccess->delete($path, $args);
         
         if($isdeleted)
            {
             $result['error'] = false;
             $result['message'] = 'Delete riuscito';
             
             return $response->write(json_encode($result));
             //return $response->withStatus(204);
            }

         else
            {
             $result['error'] = true;
             $result['message'] = 'Delete fallito';
             
             return $response->write(json_encode($result)); 
             //return $response->withStatus(404);
            }
        }
        
        
        
        //funzione per mostrare la pagina per inserire un nuovo medico
        public function addMedico(Request $request, Response $response, $args)
        {
        	$this->view->render($response, 'addMedico.twig',$_SESSION);
        	
        	unset($_SESSION['message']);
        	 
        	return $response->withHeader('Content-type', 'text/html');
        }   
        
        // verifica del codice (permesso o meno ad inviare il questionario) --> prima di effettuare la post
        public function code_verify(Request $request, Response $response, $next)
        {
        	
        	if (isset($request->getQueryParams()["code"]) && $request->getQueryParams()["code"]=='00aa')
        	{
        		$result = array();
             	$result['error'] = false;
             	$error['message'] = 1;
             
             	//return $response->withJson($error, 404);
             	return $response->write(json_encode($error));
        	}
        	else 
        	{
				$result = array();
				$result["error"] = 403;
				$result["description"] = 'Wrong code';
				return $response->withJson($result, 403);
        	}
        	
        }

        
        
        
        
        
        //DA QUI
        
        //funzione per mostrare la pagina per visualizzare l'elenco dei pazienti del medico
        public function homepage(Request $request, Response $response, $args)
        {

        	$this->view->render($response, 'home.twig', $_SESSION);
        	
        
        	return $response->withHeader('Content-type', 'text/html');
        	
        	
        }
        
        //funzione per mostrare la pagina per visualizzare l'elenco dei pazienti del medico
        public function piano(Request $request, Response $response, $args)
        {
        
        	$this->view->render($response, 'piano.twig', $_SESSION);
        	
        
        	return $response->withHeader('Content-type', 'text/html');
        }
        
        
        
        //funzione per mostrare la pagina per visualizzare l'elenco dei pazienti del medico
        public function resoconto(Request $request, Response $response, $args)
        {
        	$this->view->render($response, 'resoconto.twig', $_SESSION);
        
        
        	return $response->withHeader('Content-type', 'text/html');
        }
        
    }

?>
